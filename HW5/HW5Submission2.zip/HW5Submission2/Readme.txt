Question1: 

Screenshot name: Q1_Screenshot
File name: weights.h5

Question2: 

Screenshot name: Q2_Screenshot
Catness Cat: RashCat.jpg
Dogness Dog: Mylo.jpg

Question3:

Screenshot name: Q3_Screenshot
Trick Cat: Husky_cat.jpeg
Trick Dog: cat_as_dog.jpg